package View;

public enum RoomType {
    SINGLE,
    DOUBLE,
    SUITE,
    MATRIMONIAL
}
